package programainterfaz;
public class Persona implements PuedeCantar{

    /**
     *
     */
    @Override
public void cantar() { 
    System.out.println("do re mi fa sol la si");
} 
    
}
