package programainterfaz;
public class Burro implements PuedeCantar{
     /**
     *
     */
    @Override
 public void cantar() { 
    System.out.println("o o o o"); 
   	 } 
}
