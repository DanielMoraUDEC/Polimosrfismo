package programainterfaz;
public interface PuedeCantar {
public void cantar();    
}
