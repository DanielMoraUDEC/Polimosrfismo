package programainterfaz;
public class Canario implements PuedeCantar{

    /**
     *
     */
    @Override
 public void cantar() { 
    System.out.println("pio pio pio"); 
   	 } 
   
}
